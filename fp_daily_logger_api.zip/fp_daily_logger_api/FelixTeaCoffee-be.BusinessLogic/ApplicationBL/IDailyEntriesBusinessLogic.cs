﻿using FelixTeaCoffee_be.Data.CustomModels;
using FelixTeaCoffee_be.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FelixTeaCoffee_be.BusinessLogic.ApplicationBL
{
    public interface IDailyEntriesBusinessLogic
    {
        Task<bool> CreateApplication(ApplicationDTO applications);
        Task<List<DailyEntries>> GetEntries();
    }
}
