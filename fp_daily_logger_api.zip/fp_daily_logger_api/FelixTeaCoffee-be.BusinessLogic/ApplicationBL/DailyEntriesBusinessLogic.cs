﻿using FelixTeaCoffee_be.Data.CustomModels;
using FelixTeaCoffee_be.Data.Models;
using FelixTeaCoffee_be.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static FelixTeaCoffee_be.Data.Enums.ItemTypeEnum;
using static System.Net.Mime.MediaTypeNames;

namespace FelixTeaCoffee_be.BusinessLogic.ApplicationBL
{
    public class DailyEntriesBusinessLogic : IDailyEntriesBusinessLogic
    {
        private readonly IGenericRepository<int, Users> _userRepository;
        private readonly IGenericRepository<int, DailyEntries> _dailyentriesRepository;

        public DailyEntriesBusinessLogic(IGenericRepository<int, DailyEntries> dailyentriesRepository, IGenericRepository<int, Users> userrepository)
        {
            _dailyentriesRepository = dailyentriesRepository;
            _userRepository = userrepository;


        }
        public async Task<bool> CreateApplication(ApplicationDTO applications)
        {
            if (applications == null)
            {
                throw new ArgumentNullException(nameof(applications), "Please enter your application details.");
            }

            List<DailyEntries> applicationsToAdd = new List<DailyEntries>();

            if (applications.TeaCount > 0)
            {
                var teaApplication = new DailyEntries()
                {
                    Date = applications.Date,
                    CreatedBy = 1,
                    CreatedOn = DateTime.Now,
                    UserId = applications.UserId,
                    ItemType = ItemType.Tea,
                    Count = applications.TeaCount
                };
                applicationsToAdd.Add(teaApplication);
            }
            if (applications.CoffeeCount > 0)
            {
                var coffeeApplication = new DailyEntries()
                {
                    Date = applications.Date,
                    CreatedBy = 1,
                    CreatedOn = DateTime.Now,
                    UserId = applications.UserId,
                    ItemType = ItemType.Coffee,
                    Count = applications.CoffeeCount
                };
                applicationsToAdd.Add(coffeeApplication);
            }

            await _dailyentriesRepository.AddAllAsync(applicationsToAdd);

            return true;
        }
        public async Task<List<DailyEntries>> GetEntries()
        {
            var entries = await _dailyentriesRepository.AllAsync();
            return entries;
        }



    }
}
