﻿using FelixTeaCoffee_be.Data.CustomModels;
using FelixTeaCoffee_be.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FelixTeaCoffee_be.BusinessLogic.UserBL
{
    public interface IUserBusinessLogic
    {
        Task<UserDto> CreateUser(UserDto users);
        //List<Users> GetUsers();
        Task<LoginDto> CreateLogin(LoginDto login);
        Task<bool> ForgotPassword(string Email);
        Task<Users> VerifyOTP(string Email, int OTP);
    }
}
