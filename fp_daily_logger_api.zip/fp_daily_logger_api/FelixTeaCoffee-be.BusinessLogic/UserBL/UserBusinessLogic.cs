﻿using FelixTeaCoffee_be.Data.CustomModels;
using FelixTeaCoffee_be.Data.Models;
using FelixTeaCoffee_be.Repository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FelixTeaCoffee_be.BusinessLogic.UserBL
{
    public class UserBusinessLogic :IUserBusinessLogic
    {
        private readonly IGenericRepository<int, Users> _userRepository;
        public UserBusinessLogic(IGenericRepository<int, Users> userRepository)
        {
            _userRepository = userRepository;
        }
        public async Task<UserDto> CreateUser(UserDto user)
        {
            if (user.Email == null || user.Password == null)
            {
                throw new ArgumentNullException("user", "Please enter Password And Email");
            }

            var existingEmail = await _userRepository.FilterBy(e => e.Email == user.Email).SingleOrDefaultAsync();
            if (existingEmail != null)
            {
                throw new Exception("Error: The email already exists.");
            }
            else
            {
                PasswordEncryption encrypt = new PasswordEncryption();

                Users userData = new Users()
                {
                    Password = encrypt.HashPasword(user.Password, out var salt),
                    Salt = Convert.ToBase64String(salt),
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Email = user.Email,
                    CreatedBy = user.UserId,
                    CreatedOn = DateTime.Now,
                    
                };


                var newUser = await _userRepository.AddAsyncEntity(userData);


                // Map Users entity to UserDTO
                UserDto userDTO = new UserDto()
                {
                    UserId = newUser.Id,
                    FirstName = newUser.FirstName,
                    LastName = newUser.LastName,
                    Email = newUser.Email,
                   
                   
                };


                return userDTO;
            }
        }
        public async Task<LoginDto> CreateLogin(LoginDto login)
        {
            try
            {
                var logindata = await _userRepository.FilterBy(x => x.Email == login.Email).SingleOrDefaultAsync();

                if (logindata != null)
                {
                    PasswordEncryption encrypt = new PasswordEncryption();
                    if (encrypt.VerifyPassword(login.Password, logindata.Password, Convert.FromBase64String(logindata.Salt)))
                    {

                        var loginDto = new LoginDto
                        {
                            UserId = logindata.Id,
                            FirstName = logindata.FirstName,
                            LastName = logindata.LastName,
                            Email = logindata.Email,




                        };
                        return loginDto;
                    }
                    else
                    {
                        throw new Exception("Invalid Password");
                    }
                }
                else
                {
                    throw new Exception("Invalid email or password.");
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public async Task<bool> ForgotPassword(string Email)
        {
            var emailcheck = await _userRepository.FilterBy(x => x.Email == Email).SingleOrDefaultAsync();
            if (emailcheck != null)
            {
                int otp = GenerateOTP();

                // Save the OTP in database for validation later

                emailcheck.OTPStore = otp;
                await _userRepository.UpdateAsync(emailcheck);

                //var emailRequest = new MailRequest
                //{
                //    ToEmail = Email,
                //    Subject = "OTP send Successfully",
                //    Body = $"Your OTP has been successfully sent.<br>Here is your OTP : " + otp
                //};

                //await SendMail(emailRequest);

                return true;
            }
            else
            {
                return false;
            }
        }
        private int GenerateOTP()
        {
            Random random = new Random();
            return random.Next(100000, 999999);
        }
        public async Task<Users> VerifyOTP(string Email, int OTP)
        {
            var users = await _userRepository.FilterBy(x => x.Email == Email).SingleOrDefaultAsync();
            if (users != null && users.OTPStore == OTP)
            {
                return users;
            }
            else
            {
                return null;
            }
        }

    }
}
