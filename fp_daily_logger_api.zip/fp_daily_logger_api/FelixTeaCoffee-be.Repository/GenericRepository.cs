﻿using FelixTeaCoffee_be.Data.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace FelixTeaCoffee_be.Repository
{
    public class GenericRepository<TKey, TEntity> : IGenericRepository<TKey, TEntity> where TEntity : class
    {
        protected readonly FelixTeaCoffeeDBContext _dbContext;
        public GenericRepository(FelixTeaCoffeeDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<bool> AddAsync(TEntity entity)
        {
            if (entity is IEntity commonEntity)
            {
                setCommonFields(commonEntity);
            }
            try
            {
                _dbContext.Set<TEntity>().Add(entity);

                await _dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return true;
        }
        public async Task<TEntity> AddAsyncEntity(TEntity entity)
        {
            if (entity is IEntity commonEntity)
            {
                setCommonFields(commonEntity);
            }
            try
            {
                _dbContext.Set<TEntity>().Add(entity);

                await _dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return entity;
        }
        private void setCommonFields(IEntity entity)
        {
            if (entity.CreatedBy == null)
            {
                entity.CreatedBy = 1;
                entity.CreatedOn = DateTime.Now;
            }
        }
        public IQueryable<TEntity> FilterBy(Expression<Func<TEntity, bool>> criteria)
        {
            return _dbContext.Set<TEntity>().Where(criteria);
        }

        public IQueryable<TEntity> FilterBy(Expression<Func<TEntity, bool>> criteria, params Expression<Func<TEntity, object>>[] includeExpressions)
        {
            var query = _dbContext.Set<TEntity>().AsQueryable();

            foreach (var includeExp in includeExpressions)
            {
                query = query.Include(includeExp);
            }

            return query.Where(criteria);
        }
        public async Task<List<TEntity>> AllAsync()
        {
            return await _dbContext.Set<TEntity>().ToListAsync();
        }
        public async Task<bool> UpdateAsync(TEntity entity)
        {
            if (entity is IEntity commonEntity)
            {
                setCommonFields(commonEntity);
            }
            _dbContext.Entry(entity).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
            return true;
        }
        public async Task<bool> AddAllAsync(IEnumerable<TEntity> entities)
        {
            foreach (TEntity entity in entities)
            {
                if (entity is IEntity commonEntity)
                {
                    setCommonFields(commonEntity);
                }
            }
            _dbContext.Set<TEntity>().AddRange(entities);
            await _dbContext.SaveChangesAsync();

            return true;
        }
    }
}
