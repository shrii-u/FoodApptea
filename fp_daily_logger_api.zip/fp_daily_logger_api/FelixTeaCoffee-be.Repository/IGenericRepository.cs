﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace FelixTeaCoffee_be.Repository
{
    public interface IGenericRepository<TKey, TEntity> where TEntity : class
    {
      
        Task<bool> AddAsync(TEntity entity);
        Task<List<TEntity>> AllAsync();
        Task<TEntity> AddAsyncEntity(TEntity entity);
        IQueryable<TEntity> FilterBy(Expression<Func<TEntity, bool>> criteria);
        IQueryable<TEntity> FilterBy(Expression<Func<TEntity, bool>> criteria,
            params Expression<Func<TEntity, object>>[] includeExpressions);
        Task<bool> AddAllAsync(IEnumerable<TEntity> entities);
        Task<bool> UpdateAsync(TEntity entity);

    }
}
