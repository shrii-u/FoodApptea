using FelixTeaCoffee_be.BusinessLogic.ApplicationBL;
using FelixTeaCoffee_be.BusinessLogic.UserBL;
using FelixTeaCoffee_be.Data.Data;
using FelixTeaCoffee_be.Data.Models;
using FelixTeaCoffee_be.Repository;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddDbContext<FelixTeaCoffeeDBContext>(opt => opt.UseSqlServer(builder.Configuration["ConnectionStrings:DefaultConnection"]), ServiceLifetime.Scoped);
builder.Services.AddScoped(typeof(IGenericRepository<int, Users>), typeof(GenericRepository<int, Users>));
builder.Services.AddScoped(typeof(IUserBusinessLogic), typeof(UserBusinessLogic));
builder.Services.AddScoped(typeof(IGenericRepository<int, DailyEntries>), typeof(GenericRepository<int, DailyEntries>));
builder.Services.AddScoped(typeof(IDailyEntriesBusinessLogic), typeof(DailyEntriesBusinessLogic));
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll",
        builder =>
        {
            builder.AllowAnyOrigin()
                   .AllowAnyMethod()
                   .AllowAnyHeader();
        });
});

var app = builder.Build();

// Configure the HTTP request pipeline.

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();
app.UseCors("AllowAll");



app.Run();
