﻿namespace FelixTeaCoffee_be
{
    public class CommonAPIConstants
    {
        public string SuccessListMsg = "Data list generated successfully";
        public string SuccessMsg = " Data Found ";
        public string SuccessOTP = "OTP generated";
        public string SuccessAddMsg = "Data added successfully";
        public string SucccessUpdateMsg = "Data updated successfully";
        public string SuccessDeleteMsg = "Data deleted successfully";

        public string BadRequestMsg = "Bad Request Error";
        public string UnauthorizedMsg = "Unauthorized User Request Error";
        public string NotFoundMsg = "Not Found Request Error";
        public string OtpNotMatched = "OTP Not Matched";
        public string InternalServerMsg = "Internal Server Error";

        public string LoginMsg = "Login Successful";
        public string LoginError = "User Not Found ";
        public string PasswordError = "Password Incorect";
        public string ForgotPwdMsg = "Password Reset Successfully";
        public string RegisterError = "Email Already Exist";
        public string RegisterSuccess = "Register Successfull";
    }
}
