﻿using FelixTeaCoffee_be.BusinessLogic.ApplicationBL;
using FelixTeaCoffee_be.Data.CustomModels;
using FelixTeaCoffee_be.Data.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace FelixTeaCoffee_be.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DailyEntryController : ControllerBase
    {
        private readonly IDailyEntriesBusinessLogic _applicationBusinessLogic;


        CommonAPIConstants commonAPIConstants = new CommonAPIConstants();
        public DailyEntryController(IDailyEntriesBusinessLogic applicationBusinessLogic)
        {
            _applicationBusinessLogic = applicationBusinessLogic;
        }


        [HttpPost]
        [Route("create")]
        public async Task<APICommonResponse<bool>> AddApplication([FromBody] ApplicationDTO applications)
        {
            var ApplicationCreate = await _applicationBusinessLogic.CreateApplication(applications);

            if (ApplicationCreate != null)
            {
                if (applications.Id == null || applications.Id == 0)
                {
                    return new APICommonResponse<bool>(true, (int)HttpStatusCode.Created, commonAPIConstants.SuccessAddMsg, ApplicationCreate);
                }
                else
                {
                    return new APICommonResponse<bool>(true, (int)HttpStatusCode.OK, commonAPIConstants.SucccessUpdateMsg, ApplicationCreate);
                }

            }
            else
            {
                return new APICommonResponse<bool>(false, (int)HttpStatusCode.InternalServerError, commonAPIConstants.InternalServerMsg, ApplicationCreate);
            }
        }
        [HttpGet]
        [Route("getAll")]
        public async Task<APICommonResponse<List<DailyEntries>>> GetAllEntries()
        {
            var entries = await _applicationBusinessLogic.GetEntries();

            if (entries.Count > 0)
            {
                return new APICommonResponse<List<DailyEntries>>(true, (int)HttpStatusCode.OK, commonAPIConstants.SuccessListMsg, entries);
            }
            else
            {
                return new APICommonResponse<List<DailyEntries>>(false, (int)HttpStatusCode.OK, commonAPIConstants.NotFoundMsg, entries);
            }
        }

    }
}
