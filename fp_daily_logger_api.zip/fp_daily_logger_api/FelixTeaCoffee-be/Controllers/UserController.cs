﻿using FelixTeaCoffee_be.BusinessLogic.UserBL;
using FelixTeaCoffee_be.Data.CustomModels;
using FelixTeaCoffee_be.Data.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace FelixTeaCoffee_be.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserBusinessLogic _userBusinessLogic;


        CommonAPIConstants commonAPIConstants = new CommonAPIConstants();

        public UserController(IUserBusinessLogic userBusinessLogic)
        {
            _userBusinessLogic = userBusinessLogic;

        }

        [HttpPost]
        [Route("create")]
        public async Task<APICommonResponse<UserDto>> AddUser([FromBody] UserDto users)
        {
            try
            {
                var userCreate = await _userBusinessLogic.CreateUser(users);

                if (userCreate != null)
                {
                    return new APICommonResponse<UserDto>(true, (int)HttpStatusCode.Created, commonAPIConstants.RegisterSuccess, userCreate);
                }
                else
                {
                    return new APICommonResponse<UserDto>(false, (int)HttpStatusCode.InternalServerError, commonAPIConstants.InternalServerMsg, null);
                }
            }
            catch (Exception ex)
            {
                return new APICommonResponse<UserDto>(false, (int)HttpStatusCode.InternalServerError, commonAPIConstants.RegisterError, null);
            }
        }
        [HttpPost]
        [Route("login")]
        public async Task<APICommonResponse<LoginDto>> AddLogin([FromBody] LoginDto login)
        {
            try
            {
                var loginRequest = await _userBusinessLogic.CreateLogin(login);
                return new APICommonResponse<LoginDto>(true, (int)HttpStatusCode.OK, commonAPIConstants.LoginMsg, loginRequest);
            }
            catch (Exception ex)
            {
                if (ex.Message == "Invalid Password")
                {
                    return new APICommonResponse<LoginDto>(false, (int)HttpStatusCode.Unauthorized, commonAPIConstants.PasswordError, null);
                }
                else
                {
                    return new APICommonResponse<LoginDto>(false, (int)HttpStatusCode.InternalServerError, commonAPIConstants.LoginError, null);
                }
            }
        }
        [HttpPost]
        [Route("forgetPassword")]

        public async Task<APICommonResponse<bool>> ForgotPassword([FromBody] ForgortEmailDto user)
        {
            var users = await _userBusinessLogic.ForgotPassword(user.Email);

            if (users)
            {
                return new APICommonResponse<bool>(true, (int)HttpStatusCode.OK, commonAPIConstants.SuccessOTP, true);
            }
            else
            {
                return new APICommonResponse<bool>(false, (int)HttpStatusCode.OK, commonAPIConstants.NotFoundMsg, false);
            }
        }

        [HttpPost]
        [Route("verifyOTP")]

        public async Task<APICommonResponse<Users>> VerifyOTP([FromBody] UserDto user)
        {
            var users = await _userBusinessLogic.VerifyOTP(user.Email, (int)user.OTPStore);

            if (users != null)
            {
                return new APICommonResponse<Users>(true, (int)HttpStatusCode.OK, commonAPIConstants.SuccessMsg, users);
            }
            else
            {
                return new APICommonResponse<Users>(false, (int)HttpStatusCode.OK, commonAPIConstants.OtpNotMatched, null);
            }
        }

    }
}
