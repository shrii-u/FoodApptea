﻿using FelixTeaCoffee_be.Data.Data;
using FelixTeaCoffee_be.Data.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static FelixTeaCoffee_be.Data.Enums.ItemTypeEnum;

namespace FelixTeaCoffee_be.Data.Models
{
    public class DailyEntries:CommonEntity
    {
       
        public DateTime Date { get; set; }
        public ItemType ItemType { get; set; }
        public int Count { get; set; }
        public int UserId { get; set; }
       
        
    }
}
