﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FelixTeaCoffee_be.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddedOTPToUser : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "OTPStore",
                table: "Users",
                type: "int",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "OTPStore",
                table: "Users");
        }
    }
}
