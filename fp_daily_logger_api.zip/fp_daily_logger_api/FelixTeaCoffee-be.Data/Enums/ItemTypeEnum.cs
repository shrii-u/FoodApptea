﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FelixTeaCoffee_be.Data.Enums
{
    public class ItemTypeEnum
    {       
        public enum ItemType
        {
            Tea=1,
            Coffee=2
        }
    }
}
