﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FelixTeaCoffee_be.Data.CustomModels
{
    public class ForgortEmailDto
    {
        public string Email { get; set; }   
    }
}
