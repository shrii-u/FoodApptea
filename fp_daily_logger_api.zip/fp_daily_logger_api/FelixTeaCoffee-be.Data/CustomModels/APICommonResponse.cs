﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace FelixTeaCoffee_be.Data.CustomModels
{
    public class APICommonResponse<T>
    {
        private T _data;
        private bool _success = true;
        private int _code;
        private string _message;


        [DataMember()]
        public bool success
        {
            get { return _success; }
            set { _success = value; }
        }
        public int code
        {
            get { return _code; }
            set { _code = value; }
        }

        [DataMember()]
        public string message
        {
            get { return _message; }
            set { _message = value; }
        }

        [DataMember()]
        public T data
        {
            get { return _data; }
            set { _data = value; }
        }

        public APICommonResponse(bool success, int code, string message, T data)
        {
            _success = success;
            _code = code;
            _message = message;
            _data = data;
        }
    }
}
