﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FelixTeaCoffee_be.Data.CustomModels
{
    public class ApplicationDTO
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public int TeaCount { get; set; }
        public int CoffeeCount { get; set; }
        public int UserId { get; set; } 
    }
}
