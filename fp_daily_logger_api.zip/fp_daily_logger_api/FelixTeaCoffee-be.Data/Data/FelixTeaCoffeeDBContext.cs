﻿using FelixTeaCoffee_be.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FelixTeaCoffee_be.Data.Data
{
    public class FelixTeaCoffeeDBContext: DbContext
    {
        public FelixTeaCoffeeDBContext(DbContextOptions<FelixTeaCoffeeDBContext> options) : base(options)
        {

        }

        public DbSet<Users> Users { get; set; }
        public DbSet<DailyEntries> DailyEntries { get; set;}


    }
}
