import {
  Component,
  OnInit,
  QueryList,
  ViewChildren,
  ElementRef,
} from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { IonInput } from '@ionic/angular';
import { ToastrService } from 'ngx-toastr';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-otp',
  templateUrl: './otp.page.html',
  styleUrls: ['./otp.page.scss'],
})
export class OtpPage implements OnInit {
  otpForm: FormGroup;
  email: string | null = '';
  @ViewChildren(IonInput, { read: ElementRef })
  otpInputs!: QueryList<ElementRef>;

  constructor(
    private fb: FormBuilder,
    private navCtrl: NavController,
    private auth: AppService,
    private toastr: ToastrService,
    private route: Router,
    private router: ActivatedRoute
  ) {
    this.otpForm = this.fb.group({
      0: [''],
      1: [''],
      2: [''],
      3: [''],
      4: [''],
      5: [''],
    });
  }

  ngOnInit(): void {
    this.email = this.router.snapshot.paramMap.get('Email');
    console.log(this.email);
  }

  get otpControls() {
    return Object.keys(this.otpForm.controls);
  }

  onInput(event: Event, index: number) {
    const input = event.target as HTMLInputElement;
    if (input.value.length === 1 && index < 5) {
      const nextInput = this.otpInputs.toArray()[index + 1];
      if (nextInput) {
        nextInput.nativeElement.querySelector('input').focus();
      }
    }
  }

  verifyOtp() {
    const otp = Object.values(this.otpForm.value).join('');
    console.log('Entered OTP:', otp);
    console.log('Email:', this.email); // Add this line to check the email value

    const otpObject = { OTPStore: otp, Email: this.email };
    console.log('OTP Object:', otpObject); // Log the otpObject to see its contents

    this.auth.verifyotp(otpObject).subscribe(
      (response: any) => {
        if (response.data === null) {
          this.toastr.error(response.message);
          this.route.navigate(['forgetpassword']);
          localStorage.clear();
        } else {
          this.route.navigate(['changepassword']);
          this.toastr.success(response.message);
          console.log(response.message);
        }
      },
      (error) => {
        console.error('Error:', error);
        this.toastr.error(error.message); // Change toastr.success to toastr.error for error message
      }
    );
  }
}
