import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { ToastrService } from 'ngx-toastr';
import { AppService } from 'src/app/app.service';
import { LocalService } from 'src/app/local.service';
import { AppState } from 'src/store/AppState';
import { hide, show } from 'src/store/loading/loading.actions';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  //@Input() showSidePanel: boolean = false;
  constructor(
    private route: Router,
    private fb: FormBuilder,
    private store: Store<AppState>,
    private auth: AppService,
    private toastr: ToastrService,
    private localStore: LocalService
  ) {}
  loginForm = this.fb.nonNullable.group({
    Email: ['', [Validators.email, Validators.required]],
    Password: ['', [Validators.required, Validators.minLength(6)]],
  });

  ngOnInit() {}
  ForgotEmailPassword() {
    this.store.dispatch(show());

    setTimeout(() => {
      this.store.dispatch(hide());
      this.route.navigate(['forgetpassword']);
    }, 2000);
  }
  login() {
    if (!this.loginForm) {
      return;
    }

    this.auth.getLogin(this.loginForm.value).subscribe(
      (response: any) => {
        if (response.data === null) {
          this.toastr.error(response.message);
          this.route.navigate(['login']);
        } else {
          this.route.navigate(['home']);
          this.localStore.saveData('Login_Data', JSON.stringify(response.data));
          this.toastr.success(response.message);
          console.log(response.message);
        }
      },
      (error) => {
        console.error('Error:', error);
        this.toastr.success(error.message);
      }
    );
  }
}
