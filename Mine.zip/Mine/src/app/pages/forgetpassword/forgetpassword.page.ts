import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-forgetpassword',
  templateUrl: './forgetpassword.page.html',
  styleUrls: ['./forgetpassword.page.scss'],
})
export class ForgetpasswordPage implements OnInit {
  constructor(
    private fb: FormBuilder,
    private auth: AppService,
    private toastr: ToastrService,
    private route: Router
  ) {}
  forgotForm = this.fb.nonNullable.group({
    Email: ['', [Validators.email, Validators.required]],
  });
  ngOnInit() {}
  login() {
    this.route.navigate(['login']);
  }
  forgotPassword() {
    const Email = this.forgotForm.value;
    console.log(Email);
    this.auth.forgotpassward(Email).subscribe(
      (response: any) => {
        if (response.success === false) {
          this.toastr.error(response.message);
          this.route.navigate(['login']);
        } else {
          localStorage.setItem('forgotPasswordEmail', JSON.stringify(Email));
          this.route.navigate(['otp', Email]);
          this.toastr.success(response.message);
          console.log(response.message);
        }
      },
      (error) => {
        console.error('Error:', error);
        this.toastr.success(error.message);
      }
    );
  }
}
