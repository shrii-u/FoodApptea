import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-adddailyentries',
  templateUrl: './adddailyentries.page.html',
  styleUrls: ['./adddailyentries.page.scss'],
})
export class AdddailyentriesPage implements OnInit {
  DailyEntryForm!: FormGroup;

  constructor(
    private fb: FormBuilder,
    private auth: AppService,
    private route: Router,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.DailyEntryForm = this.fb.group({
      Date: ['', [Validators.required]],
      TeaSelected: [false],
      TeaCount: [{ value: '', disabled: true }],
      CoffeeSelected: [false],
      CoffeeCount: [{ value: '', disabled: true }],
    });

    // Set up validators dynamically based on checkbox changes
    this.DailyEntryForm.get('TeaSelected')?.valueChanges.subscribe(
      (checked) => {
        if (checked) {
          this.DailyEntryForm.get('TeaCount')?.setValidators([
            Validators.required,
          ]);
        } else {
          this.DailyEntryForm.get('TeaCount')?.clearValidators();
        }
        this.DailyEntryForm.get('TeaCount')?.updateValueAndValidity();
      }
    );

    this.DailyEntryForm.get('CoffeeSelected')?.valueChanges.subscribe(
      (checked) => {
        if (checked) {
          this.DailyEntryForm.get('CoffeeCount')?.setValidators([
            Validators.required,
          ]);
        } else {
          this.DailyEntryForm.get('CoffeeCount')?.clearValidators();
        }
        this.DailyEntryForm.get('CoffeeCount')?.updateValueAndValidity();
      }
    );
  }

  toggleTeaCount(event: any) {
    const isChecked = event.detail.checked;
    if (isChecked) {
      this.DailyEntryForm.get('TeaCount')?.enable();
    } else {
      this.DailyEntryForm.get('TeaCount')?.disable();
    }
  }

  toggleCoffeeCount(event: any) {
    const isChecked = event.detail.checked;
    if (isChecked) {
      this.DailyEntryForm.get('CoffeeCount')?.enable();
    } else {
      this.DailyEntryForm.get('CoffeeCount')?.disable();
    }
  }
  navigateBack() {
    this.route.navigate(['/home']);
  }
  Add() {
    if (this.DailyEntryForm.invalid) {
      console.log('Please fill in all required fields.');
      this.toastr.error('Please fill in all required fields.');
      return;
    }

    console.log(this.DailyEntryForm.value);
    const dateValue = this.DailyEntryForm.value.Date;
    const dataToSend = {
      Date: dateValue ? dateValue : '',
      TeaCount:
        this.DailyEntryForm.value.TeaCount !== null
          ? this.DailyEntryForm.value.TeaCount
          : 0,
      CoffeeCount:
        this.DailyEntryForm.value.CoffeeCount !== null
          ? this.DailyEntryForm.value.CoffeeCount
          : 0,
    };

    console.log('data', dataToSend);

    this.auth.createDailyEntry(dataToSend).subscribe(
      (response: any) => {
        this.route.navigate(['home']);
        this.toastr.success(response.message);
      },
      (error) => {
        console.error('Error', error);
        this.toastr.error(error.message);
      }
    );
  }
}
