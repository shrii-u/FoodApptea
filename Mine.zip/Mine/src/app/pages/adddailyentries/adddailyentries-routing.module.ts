import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdddailyentriesPage } from './adddailyentries.page';

const routes: Routes = [
  {
    path: '',
    component: AdddailyentriesPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdddailyentriesPageRoutingModule {}
