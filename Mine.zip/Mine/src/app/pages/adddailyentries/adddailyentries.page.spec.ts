import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdddailyentriesPage } from './adddailyentries.page';

describe('AdddailyentriesPage', () => {
  let component: AdddailyentriesPage;
  let fixture: ComponentFixture<AdddailyentriesPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(AdddailyentriesPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
