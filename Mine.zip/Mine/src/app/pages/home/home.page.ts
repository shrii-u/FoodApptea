import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {
  // @Input() showSidePanel: boolean = true;
  constructor(private route: Router, private auth: AppService) {}
  entries: any[] = [];
  totalTeaCount: number = 0;
  totalCoffeeCount: number = 0;
  ngOnInit() {
    this.auth.getDailyEntryList().subscribe(
      (response: any) => {
        console.log(response);

        this.entries = response.data;
        const teaEntries = this.entries.filter((entry) => entry.itemType === 1);
        const CoffeeEntries = this.entries.filter(
          (entry) => entry.itemType === 2
        );

        this.totalTeaCount = teaEntries.reduce(
          (total, entry) => total + entry.count,
          0
        );
        this.totalCoffeeCount = CoffeeEntries.reduce(
          (total, entry) => total + entry.count,
          0
        );
      },
      (error) => {
        console.error('Error fetching entries:', error);
      }
    );
  }

  navigate() {
    this.route.navigate(['adddailyentries']);
  }
}
