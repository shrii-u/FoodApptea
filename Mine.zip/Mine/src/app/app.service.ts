import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { map } from 'rxjs';
import { environment } from 'src/environments/environment';
const headers = new HttpHeaders({
  'Content-Type': 'application/json',
});
const blobHeaders = new HttpHeaders({
  Accept: 'application/octet-stream', // Accept blob response
});
const form_header = new HttpHeaders({
  'Content-Type': 'application/x-www-form-urlencoded',
});
@Injectable({
  providedIn: 'root',
})
export class AppService {
  readonly apiURL = environment.baseUrl;
  data: any;
  options = {
    headers,
  };
  form_options = {
    form_header,
    observe: 'body' as const,
  };
  blob_options = {
    blobHeaders,
    responseType: 'blob' as 'json',
    observe: 'body' as const,
  };

  constructor(private http: HttpClient) {}

  getLogin(requestBody: any) {
    return this.http.post<any[]>(
      this.apiURL + 'User/login',
      requestBody,
      this.options
    );
  }

  verifyotp(requestBody: any) {
    return this.http.post<any[]>(
      this.apiURL + 'User/verifyOTP',
      requestBody,
      this.options
    );
  }
  changepassword(requestBody: any) {
    return this.http.post<any[]>(
      this.apiURL + 'User/changePassword',
      requestBody,
      this.options
    );
  }
  getDailyEntryList() {
    return this.http.get<any[]>(
      this.apiURL + 'DailyEntry/getall',
      this.options
    );
  }
  createDailyEntry(requestBody: any) {
    return this.http.post<any[]>(
      this.apiURL + 'DailyEntry/create',
      requestBody
    );
  }
  forgotpassward(requestBody: any) {
    return this.http.post<any[]>(
      this.apiURL + 'User/forgetPassword',
      requestBody,
      this.options
    );
  }
}
