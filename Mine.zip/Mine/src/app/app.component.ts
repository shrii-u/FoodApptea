import { Component } from '@angular/core';
import { LocalService } from './local.service';
import { NavigationEnd, Router } from '@angular/router';
import { MenuController } from '@ionic/angular';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  public appPages = [];
  FullName: any;
  Email: any;

  //showSidePanel: boolean = true;

  constructor(
    private localService: LocalService,
    private route: Router,
    private menuController: MenuController
  ) {
    // this.route.events.subscribe((event) => {
    //   if (event instanceof NavigationEnd) {
    //     this.showSidePanel = event.urlAfterRedirects === '/home';
    //   }
    // });
  }
  ngOnInit(): void {
    const loginData = localStorage.getItem('Login_Data');

    if (loginData) {
      const userData = JSON.parse(loginData);
      console.log(loginData);
      this.FullName = userData.firstName + '  ' + userData.lastName;
      console.log(this.FullName);
      this.Email = userData.email;
    }
    // this.route.events.subscribe((event) => {
    //   if (event instanceof NavigationEnd) {
    //     this.showSidePanel = event.urlAfterRedirects === '/home';
    //   }
    // });
  }
  home() {
    this.menuController.close().then(() => {
      this.route.navigateByUrl('/home');
    });
  }
  logout() {
    this.localService.clearData();

    this.menuController.close().then(() => {
      this.route.navigateByUrl('/login');
    });
  }
}
