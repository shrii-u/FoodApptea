import { inject } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  Router,
  RouterStateSnapshot,
} from '@angular/router';
import { LocalService } from './local.service';

export const authGuard = (
  route?: ActivatedRouteSnapshot,
  state?: RouterStateSnapshot
) => {
  const router = inject(Router);
  const localService = inject(LocalService);
  const currentRoute = route?.pathFromRoot
    .map((v: ActivatedRouteSnapshot) => v.url)
    .reduce((acc, val) => acc.concat(val), [])
    .join('/');

  let loggedInUserData: any;
  let Email: any;

  try {
    loggedInUserData = JSON.parse(localService.getData('Login_Data') ?? '{}');
    Email = JSON.parse(localService.getData('forgotPasswordEmail') ?? '{}');
  } catch (error) {
    console.error('Error parsing JSON from local storage:', error);
    loggedInUserData = {}; // Default to an empty object if parsing fails
  }

  let finalOutcome: any = undefined;

  // if user is logged in.
  if (Object.keys(loggedInUserData).length > 0) {
    // If user hits auth related URL.
    if (currentRoute && currentRoute?.indexOf('login') > -1) {
      finalOutcome = router.parseUrl('/home');
      // If any other URL is hit except auth related URL
    }
    // If user is not logged in and hits auth related URL.
  } else if (currentRoute && currentRoute?.indexOf('login') > -1) {
    finalOutcome = true;
    // If user is not logged in and hits any other URL apart from auth related URL.
  } else {
    finalOutcome = router.parseUrl('/login');
  }

  return finalOutcome;
};
