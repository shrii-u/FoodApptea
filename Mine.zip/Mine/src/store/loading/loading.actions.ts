import { createAction } from '@ngrx/store';

export const show = createAction('[Loading] show');
export const hide = createAction('[Loading] hide');
