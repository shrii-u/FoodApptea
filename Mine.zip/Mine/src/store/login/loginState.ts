export interface LoginState {
    error: any;
    isRecoveringPassword: boolean;
    isRecoveredPassword: boolean;
    isLoggingIn: boolean;
    isLoggedIn: boolean;
  }
  